<?php
// For Store data
session_start();
// For Remove data
session_destroy();
// Back To the Login Page
header('Location: loginPage.php');


?>