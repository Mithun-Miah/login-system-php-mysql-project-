<?php
// For Store data
session_start();

// Database Connection code Start
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "login_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['submit'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $confnewpass = $_POST['confnewpass'];
	
	if($newpass != $confnewpass){
		echo "<script>alert('New Password And Confirm Password Not Match!')</script>"; 
	}else{
		$query = mysqli_query($conn, "SELECT email,password from user_info where email = '$email' 
    AND password = '$oldpass' ");

    $num = mysqli_fetch_array($query);

    if($num>0){
        $con = mysqli_query($conn, "UPDATE user_info set password = '$newpass' where email = '$email' ");
   
        echo "<script>alert('Password change success')</script>";
    }else{
        echo "<script>alert('Current Password does not match')</script>";
    }
	
	}
    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Change Password</title>

    <style>
        h1{
            background-color: blue;
            color: #fff;
            padding: 10px;
            margin: 10px;
            text-align: center;
        }
        form{
            width: 600px;
            border: 2px solid red;
            padding: 10px;
            margin: auto;
        }
        form input{
            width: 95%;
            padding: 20px;
            border-radius: 10px;
            font-size: 18px;
        }
        #submitBtn{
            cursor: pointer;
            font-size: 20px;
            font-weight: 700;
            transition: 0.3s;
        }
        #submitBtn:hover{
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>

<form action="" method="POST">
    <h1>Change Your Password</h1>
    <input type="email" name="email" placeholder="Enter email">
    <br><br>
    <input type="password" name="oldpass" placeholder="Enter Old Password">
    <br><br>
    <input type="password" name="newpass" placeholder="Enter New Password">
    <br><br>
    <input type="password" name="confnewpass" placeholder="Enter New Password Again">
    <br><br>
    <input type="submit" name="submit" id="submitBtn" value="Change Password">

</form>
    
</body>
</html>