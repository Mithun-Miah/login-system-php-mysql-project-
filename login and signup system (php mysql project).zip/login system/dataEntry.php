<?php
// ====================================================
// For Store data
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Email : $_SESSION[email]</h1>");
    // echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: loginPage.php');
}
// =====================================================
// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "data_entry");

if(isset($_POST['send'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dept = $_POST['dept'];

    // Email Validation Code
    $email_select = "SELECT * FROM insert_data WHERE email = '$email' ";
    // Email Validation Code Execute
    $email_exc = mysqli_query($connect, $email_select);
    // Email Validation Code Execute for Number of Rows
    $count = mysqli_num_rows($email_exc);

    // Email Condition check
    if($count>0){
        echo "<script>alert('Email Already Exist')</script>";
    } else {
        // Inser Data Query Format with Email validation
        //"INSERT INTO TABLE_NAME (COLUMN_NAME) VALUES (VALUE)";
        $query = "INSERT INTO insert_data (name, email, phone, dept) VALUES ('$name', '$email', '$phone', '$dept')";
        
        $insert = mysqli_query($connect, $query);

        if($insert){
            echo "<script>alert('data send Success')</script>";
        } else{
            echo "<script>alert('Data send Fail')</script>";
        }
    }
    
} 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Insert</title>

    <style>
        .container{
            width: 500px;
            /* border: 1px solid black; */
            height: 400px;
            margin: 0px auto;
            text-align: center;
            padding: 10px;
        }
        h1 {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
        }
        form input {
            border: 2px solid green;
            width: 90%;
            padding: 10px;
        }
        select {
            width: 90%;
            padding: 10px;
            border: 2px solid green;
        }

        button {
            padding: 10px;
            width: 90%;
            color: white;
            background-color: green;
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 2px;
            border: none;
            cursor: pointer;
            transition: 0.2s ease-in;
        }
        button:hover {
            background-color: blue;
        }
        table,th,td{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 3px;
        }
        .logoutDiv{
            margin-bottom: 20px;
            text-align: right;
        }
        .logout, .homeBtn{
            text-decoration: none;
            background-color: red;
            color: white;
            padding: 10px;
            font-size: 1.2rem;
            border-radius: 5px;
            font-size: 1.3rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }
        .logout:hover{
            background-color: brown;
            color: white;
        }
        .homeBtn:hover{
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>

    <h1>Insert Data</h1>
    <div class="container">
        <div class="logoutDiv">
            <a href="logout.php" class="logout">Logout</a>
            <a href="mainWindow.php" class="homeBtn">Home</a>
        </div>
        <form method="POST">
            <input type="text" name="name" placeholder="name" require> <br><br>
            <input type="email" name="email" placeholder="email" require> <br><br>
            <input type="text" name="phone" placeholder="phone" require> <br><br>
            <select name="dept" id="">
                <option value="CSE">CSE</option>
                <option value="EEE">EEE</option>
                <option value="BBA">BBA</option>
            </select> <br><br>
            <!-- <input type="submit" value="Submit"> -->
            <button name="send">Send</button>
        </form>

        <br>

        <h1>Read PHP Fetch Data</h1>

        <table>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Department</th>
            <th>Edit</th>
            <th>Delete</th>

        <?php
        $read = "SELECT * FROM insert_data";
        $query = mysqli_query($connect, $read);
        
        //Database Rows Count Code
        // $count = mysqli_num_rows($query);
        // echo "<h3>Total Database Row : </h3>". $count;

        while($row = mysqli_fetch_array($query)){ ?>
            
            <tr>
                <td><?php echo $row["Id"];?></td>
                <td><?php echo $row["name"];?></td>
                <td><?php echo $row["email"];?></td>
                <td><?php echo $row["phone"];?></td>
                <td><?php echo $row["dept"];?></td>
                <td><a href="edit.php?idNo=<?php echo $row['Id']; ?>">edit</a></td>
                <td><a onclick="return confirm('Do You Want To Delete !')" href="delete.php?idNo=<?php echo $row['Id']; ?>">delete</a></td>
            </tr>

        <?php }
        
        ?>

        <!-- After refresh/reload Data Resubmission Stop with this code -->
        <script>
            if(window.history.replaceState){
                window.history.replaceState(null,null,location.href)
            }
        </script>
        </table>

        <br><br><br>

    </div>
    
    
</body>
</html>