<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "data_entry");

    $id = $_GET['idNo'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM insert_data WHERE Id = $id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:dataEntry.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>