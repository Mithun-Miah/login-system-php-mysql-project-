<?php
// For Store data
session_start();

// Database Connection code Start
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "login_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['submit'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $newpass = $_POST['newpass'];

    $query = "UPDATE user_info SET password = '$newpass' WHERE email = '$email' ";

    $data = mysqli_query($conn, $query);

    if($data){
   
        echo "<script>alert('New Password Create success')</script>";
    }else{
        echo "<script>alert('Email Id does not match')</script>";
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Change Password</title>

    <style>
        h1{
            background-color: blue;
            color: #fff;
            padding: 10px;
            margin: 10px;
            text-align: center;
        }
        form{
            width: 600px;
            border: 2px solid red;
            padding: 10px;
            margin: auto;
        }
        form input{
            width: 95%;
            padding: 20px;
            border-radius: 10px;
            font-size: 18px;
        }
        #submitBtn{
            cursor: pointer;
            font-size: 20px;
            font-weight: 700;
            transition: 0.3s;
        }
        #submitBtn:hover{
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>

<form action="" method="POST">
    <h1>Change Your Password</h1>
    <input type="email" name="email" placeholder="Enter email">
    <br><br>
    <!-- <input type="password" name="oldpass" placeholder="Enter Old Password">
    <br><br> -->
    <input type="password" name="newpass" placeholder="Enter New Password">
    <!-- <br><br>
    <input type="password" name="confnewpass" placeholder="Confirm New Password"> -->
    <br><br>
    <input type="submit" name="submit" id="submitBtn" value="Change Password">

</form>
    
</body>
</html>